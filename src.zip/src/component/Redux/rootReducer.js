
//using when use redux core
// import {combineReducers} from 'redux'
// import adminslice from "./adminslice"
// import toolslice from "./toolslice"


// //OPTION 1
// // const rootReducer = (state = {} , action) => {
// //             return {
// //                 tool: toolReducer(state.tool,action),
// //                 admin: adminReducer(state.admin,action)
// //             };
// // };


//OPTION 2
// const rootReducer = combineReducers({
//     tool: toolslice,
//     admin: adminslice
// })


// export default rootReducer
import React from "react"
import "./Tooloverview.scss";




export default function Backgound(props) {

    return (
        <div className="DAT_BG">
            <div className={"DAT_BG-picture"+props.id}></div>

        </div>
    )
}
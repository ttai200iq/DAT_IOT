export const rootAction = (type,data) =>{
    return{
            type: type,
            payload:data
    }
}
